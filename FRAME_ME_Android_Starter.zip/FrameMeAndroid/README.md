# FRAME ME — Android starter project

This is a native Android Studio project starter using Kotlin and CameraX.

## Included
- Rear-camera live preview
- Zoom slider using the camera's reported zoom range
- Rule-of-thirds composition overlay placeholder
- Photo capture saved to Pictures/FRAME ME

## Important
This is source code, not an APK. It must be opened and built in Android Studio (or another compatible Android build environment), then tested on a physical phone.

The current zoom slider is manual. Automatic scene recognition and smart framing are not implemented yet. The overlay is a placeholder and can be upgraded to drawn grid lines in the next iteration.

## Build
Open this folder in Android Studio, allow Gradle sync, then build the debug APK from Build > Build Bundle(s) / APK(s) > Build APK(s).
